package com.example.encryptedchat

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * CryptoManager
 *
 * Handles AES-256/GCM encryption and decryption of chat messages.
 *
 * Key storage / risk discussion:
 * - The AES key NEVER leaves the device and is generated inside the Android
 *   Keystore (a hardware-backed secure area on most devices). We only ever
 *   hold a *reference* (alias) to the key, not the raw key bytes.
 * - Because the key lives in the Keystore, it cannot be extracted even if
 *   the device is rooted or the app's storage is dumped.
 * - Risk: if the app is uninstalled, the Keystore entry is deleted and any
 *   previously encrypted messages become permanently unreadable. This is
 *   expected behavior for a local-only prototype (no key backup/escrow).
 * - Risk: on devices without hardware-backed Keystore support, keys are
 *   protected in software only, which is weaker but still far better than
 *   storing a raw AES key in SharedPreferences or hardcoding it in source.
 * - GCM mode is used because it provides both confidentiality AND integrity
 *   (authentication tag), so tampering with ciphertext is detectable.
 */
class CryptoManager {

    private val keyAlias = "encrypted_chat_aes_key"
    private val androidKeyStore = "AndroidKeyStore"
    private val transformation = "AES/GCM/NoPadding"
    private val gcmTagLength = 128 // bits

    private val keyStore: KeyStore = KeyStore.getInstance(androidKeyStore).apply { load(null) }

    /** Returns the existing key, or generates a new one on first run. */
    private fun getOrCreateKey(): SecretKey {
        val existing = keyStore.getKey(keyAlias, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES, androidKeyStore
        )
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    /** Result of an encryption operation: ciphertext + IV, both Base64-encoded for storage. */
    data class EncryptedPayload(val cipherText: String, val iv: String)

    fun encrypt(plainText: String): EncryptedPayload {
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(
            cipherText = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP),
            iv = Base64.encodeToString(iv, Base64.NO_WRAP)
        )
    }

    fun decrypt(payload: EncryptedPayload): String {
        val cipher = Cipher.getInstance(transformation)
        val ivBytes = Base64.decode(payload.iv, Base64.NO_WRAP)
        val spec = GCMParameterSpec(gcmTagLength, ivBytes)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), spec)
        val cipherBytes = Base64.decode(payload.cipherText, Base64.NO_WRAP)
        val decryptedBytes = cipher.doFinal(cipherBytes)
        return String(decryptedBytes, Charsets.UTF_8)
    }
}
