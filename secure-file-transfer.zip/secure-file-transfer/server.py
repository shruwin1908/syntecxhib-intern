#!/usr/bin/env python3
"""
Secure File Storage Server.

The server stores files as blind encrypted chunks - it never sees the
passphrase or the derived AES/HMAC keys, only ciphertext + integrity tags.
That means a server compromise alone does not expose file contents (see
README.md "Threat Model").

Runs over HTTPS (TLS) to protect chunks in transit on the wire, as a second
layer on top of the per-chunk application-level AES+HMAC encryption.
"""

import os
import json
import uuid
import base64

from flask import Flask, request, jsonify, abort

STORAGE_DIR = os.path.join(os.path.dirname(__file__), "storage")
IV_LEN = 16
TAG_LEN = 32
MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024  # 500 MB cap - basic DoS guard

app = Flask(__name__)
os.makedirs(STORAGE_DIR, exist_ok=True)


def file_dir(file_id):
    return os.path.join(STORAGE_DIR, file_id)


def meta_path(file_id):
    return os.path.join(file_dir(file_id), "meta.json")


def load_meta(file_id):
    path = meta_path(file_id)
    if not os.path.isfile(path):
        abort(404, description="Unknown file_id")
    with open(path) as f:
        return json.load(f)


def save_meta(file_id, meta):
    with open(meta_path(file_id), "w") as f:
        json.dump(meta, f)


@app.route("/files", methods=["POST"])
def create_file():
    data = request.get_json(force=True, silent=True) or {}
    filename = data.get("filename")
    total_chunks = data.get("total_chunks")
    salt_hex = data.get("salt")

    if not filename or not total_chunks or not salt_hex:
        abort(400, description="filename, total_chunks, and salt are required")

    file_id = uuid.uuid4().hex
    os.makedirs(file_dir(file_id), exist_ok=True)

    meta = {
        "filename": filename,
        "total_chunks": total_chunks,
        "salt": salt_hex,
        "received": [],
    }
    save_meta(file_id, meta)
    return jsonify({"file_id": file_id}), 201


@app.route("/files/<file_id>/meta", methods=["GET"])
def get_meta(file_id):
    return jsonify(load_meta(file_id))


@app.route("/files/<file_id>/status", methods=["GET"])
def get_status(file_id):
    meta = load_meta(file_id)
    return jsonify({"received": sorted(meta["received"]), "total_chunks": meta["total_chunks"]})


@app.route("/files/<file_id>/chunks/<int:index>", methods=["PUT"])
def upload_chunk(file_id, index):
    meta = load_meta(file_id)
    if index < 0 or index >= meta["total_chunks"]:
        abort(400, description="chunk index out of range")

    body = request.get_json(force=True, silent=True) or {}
    try:
        iv = base64.b64decode(body["iv"])
        ciphertext = base64.b64decode(body["ciphertext"])
        tag = base64.b64decode(body["tag"])
    except (KeyError, ValueError):
        abort(400, description="iv, ciphertext, tag (base64-encoded) are required")

    if len(iv) != IV_LEN or len(tag) != TAG_LEN:
        abort(400, description="malformed iv/tag length")

    existing_size = sum(
        os.path.getsize(os.path.join(file_dir(file_id), name))
        for name in os.listdir(file_dir(file_id))
        if name.startswith("chunk_")
    )
    if existing_size + len(ciphertext) > MAX_FILE_SIZE_BYTES:
        abort(413, description="file exceeds server size limit")

    chunk_path = os.path.join(file_dir(file_id), f"chunk_{index:06d}.bin")
    with open(chunk_path, "wb") as f:
        f.write(iv + tag + ciphertext)

    if index not in meta["received"]:
        meta["received"].append(index)
        save_meta(file_id, meta)

    return jsonify({"status": "ok", "index": index}), 200


@app.route("/files/<file_id>/chunks/<int:index>", methods=["GET"])
def download_chunk(file_id, index):
    load_meta(file_id)  # 404s if unknown
    chunk_path = os.path.join(file_dir(file_id), f"chunk_{index:06d}.bin")
    if not os.path.isfile(chunk_path):
        abort(404, description="chunk not found")

    with open(chunk_path, "rb") as f:
        raw = f.read()

    iv, tag, ciphertext = raw[:IV_LEN], raw[IV_LEN:IV_LEN + TAG_LEN], raw[IV_LEN + TAG_LEN:]
    return jsonify({
        "iv": base64.b64encode(iv).decode(),
        "tag": base64.b64encode(tag).decode(),
        "ciphertext": base64.b64encode(ciphertext).decode(),
    })


@app.route("/files", methods=["GET"])
def list_files():
    out = []
    for file_id in os.listdir(STORAGE_DIR):
        try:
            meta = load_meta(file_id)
        except Exception:
            continue
        out.append({
            "file_id": file_id,
            "filename": meta["filename"],
            "total_chunks": meta["total_chunks"],
            "received_chunks": len(meta["received"]),
        })
    return jsonify(out)


if __name__ == "__main__":
    cert_path = os.path.join(os.path.dirname(__file__), "cert.pem")
    key_path = os.path.join(os.path.dirname(__file__), "key.pem")

    if os.path.isfile(cert_path) and os.path.isfile(key_path):
        ssl_context = (cert_path, key_path)
        print(f"Using cert: {cert_path}")
    else:
        print("No cert.pem/key.pem found - run `python generate_cert.py` first for a stable "
              "local cert, or continuing with Flask's ad-hoc (regenerated each run) cert.")
        ssl_context = "adhoc"

    app.run(host="0.0.0.0", port=5000, ssl_context=ssl_context)
