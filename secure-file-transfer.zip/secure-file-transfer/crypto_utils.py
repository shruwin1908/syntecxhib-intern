"""
Cryptographic primitives for Project 2: Encrypted File Transfer & Secure File Storage.

Design (per-chunk encrypt-then-MAC):
  - AES-256-CBC for confidentiality (random IV per chunk)
  - HMAC-SHA256 over (iv || ciphertext) for integrity/authenticity
  - Separate AES and HMAC keys, both derived from one shared passphrase via
    PBKDF2-HMAC-SHA256 with a random per-file salt

NOTE: a real production system would likely use AES-GCM (an AEAD cipher
that combines confidentiality + integrity in one primitive) plus a proper
key-exchange protocol (e.g. ECDH) instead of a shared passphrase. This demo
deliberately uses explicit encrypt-then-MAC + PBKDF2 so the HMAC
integrity-check step is visible and independently inspectable, per the
assignment brief. See README.md "Threat Model" for the trade-offs.
"""

import os
import hmac
import hashlib

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

AES_KEY_LEN = 32          # AES-256
HMAC_KEY_LEN = 32         # HMAC-SHA256
IV_LEN = 16
PBKDF2_ITERATIONS = 200_000


def derive_keys(passphrase: str, salt: bytes):
    """
    Derive two independent keys (one for AES, one for HMAC) from a single
    passphrase + salt. Using separate keys for encryption vs. authentication
    (rather than reusing one key for both) avoids subtle cryptographic
    interactions between the two primitives.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=AES_KEY_LEN + HMAC_KEY_LEN,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    material = kdf.derive(passphrase.encode("utf-8"))
    return material[:AES_KEY_LEN], material[AES_KEY_LEN:]


def encrypt_chunk(aes_key: bytes, mac_key: bytes, plaintext: bytes):
    """
    Encrypt one chunk: random IV, AES-256-CBC, PKCS7 padding, then
    HMAC-SHA256 over (iv || ciphertext). Returns (iv, ciphertext, tag).
    """
    iv = os.urandom(IV_LEN)

    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded = padder.update(plaintext) + padder.finalize()

    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded) + encryptor.finalize()

    tag = hmac.new(mac_key, iv + ciphertext, hashlib.sha256).digest()
    return iv, ciphertext, tag


def verify_and_decrypt_chunk(aes_key: bytes, mac_key: bytes, iv: bytes, ciphertext: bytes, tag: bytes):
    """
    Verify HMAC first (encrypt-then-MAC => verify-then-decrypt), then
    decrypt. Raises ValueError if the integrity check fails - this is what
    catches both transmission corruption and deliberate tampering,
    including by a malicious/compromised server.
    """
    expected_tag = hmac.new(mac_key, iv + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(expected_tag, tag):
        raise ValueError("HMAC verification failed - chunk may be corrupted or tampered with")

    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()

    unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
    plaintext = unpadder.update(padded) + unpadder.finalize()
    return plaintext
