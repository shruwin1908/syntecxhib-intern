"""
File chunking helpers. Large files are split into fixed-size chunks so
each one can be independently encrypted, MACed, uploaded, and (if a
transfer is interrupted) resumed without re-sending everything.
"""

import os

DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1 MiB


def iter_chunks(file_path, chunk_size=DEFAULT_CHUNK_SIZE):
    """Yield (index, raw_bytes) for each chunk of file_path, in order."""
    with open(file_path, "rb") as f:
        index = 0
        while True:
            data = f.read(chunk_size)
            if not data:
                break
            yield index, data
            index += 1


def count_chunks(file_path, chunk_size=DEFAULT_CHUNK_SIZE):
    size = os.path.getsize(file_path)
    if size == 0:
        return 1
    return (size + chunk_size - 1) // chunk_size
