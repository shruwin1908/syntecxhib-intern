#!/usr/bin/env python3
"""
Secure File Transfer Client.

Encrypts files locally (AES-256-CBC + HMAC-SHA256 per chunk) before
anything leaves this machine, uploads over HTTPS, and verifies + decrypts
on download. The server never sees the passphrase or the derived keys.

Usage:
    python client.py upload myfile.pdf
    python client.py resume myfile.pdf <file_id>      # continue an interrupted upload
    python client.py list
    python client.py download <file_id> --out restored.pdf

All commands accept --server (default https://localhost:5000) and
--verify-cert (off by default, since local self-signed certs won't
validate against a CA bundle).
"""

import argparse
import base64
import getpass
import os
import sys

import requests
import urllib3

from crypto_utils import derive_keys, encrypt_chunk, verify_and_decrypt_chunk
from chunker import iter_chunks, count_chunks, DEFAULT_CHUNK_SIZE

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_passphrase(confirm=False):
    pw = getpass.getpass("Passphrase: ")
    if confirm:
        pw2 = getpass.getpass("Confirm passphrase: ")
        if pw != pw2:
            print("Passphrases don't match.")
            sys.exit(1)
    if len(pw) < 8:
        print("Warning: short passphrases are easier to brute-force. Consider something longer.")
    return pw


def upload(args):
    if not os.path.isfile(args.file):
        print(f"File not found: {args.file}")
        sys.exit(1)

    passphrase = get_passphrase(confirm=True)
    salt = os.urandom(16)
    aes_key, mac_key = derive_keys(passphrase, salt)

    total_chunks = count_chunks(args.file, args.chunk_size)
    filename = os.path.basename(args.file)

    resp = requests.post(
        f"{args.server}/files",
        json={"filename": filename, "total_chunks": total_chunks, "salt": salt.hex()},
        verify=args.verify_cert,
    )
    resp.raise_for_status()
    file_id = resp.json()["file_id"]
    print(f"Created file record: {file_id}")

    for index, plaintext in iter_chunks(args.file, args.chunk_size):
        iv, ciphertext, tag = encrypt_chunk(aes_key, mac_key, plaintext)
        r = requests.put(
            f"{args.server}/files/{file_id}/chunks/{index}",
            json={
                "iv": base64.b64encode(iv).decode(),
                "ciphertext": base64.b64encode(ciphertext).decode(),
                "tag": base64.b64encode(tag).decode(),
            },
            verify=args.verify_cert,
        )
        r.raise_for_status()
        print(f"  uploaded chunk {index + 1}/{total_chunks}")

    print(f"\nDone. Save this file_id to download later: {file_id}")


def resume_upload(args):
    """Resume an interrupted upload: re-derives the same keys from the same
    passphrase + the salt already stored server-side, then sends only the
    chunks the server doesn't have yet."""
    status_r = requests.get(f"{args.server}/files/{args.file_id}/status", verify=args.verify_cert)
    status_r.raise_for_status()
    status = status_r.json()

    meta_r = requests.get(f"{args.server}/files/{args.file_id}/meta", verify=args.verify_cert)
    meta_r.raise_for_status()
    meta = meta_r.json()

    passphrase = get_passphrase()
    salt = bytes.fromhex(meta["salt"])
    aes_key, mac_key = derive_keys(passphrase, salt)
    received = set(status["received"])

    for index, plaintext in iter_chunks(args.file, args.chunk_size):
        if index in received:
            continue
        iv, ciphertext, tag = encrypt_chunk(aes_key, mac_key, plaintext)
        r = requests.put(
            f"{args.server}/files/{args.file_id}/chunks/{index}",
            json={
                "iv": base64.b64encode(iv).decode(),
                "ciphertext": base64.b64encode(ciphertext).decode(),
                "tag": base64.b64encode(tag).decode(),
            },
            verify=args.verify_cert,
        )
        r.raise_for_status()
        print(f"  uploaded chunk {index + 1}/{meta['total_chunks']}")

    print("Resume complete.")


def download(args):
    meta_r = requests.get(f"{args.server}/files/{args.file_id}/meta", verify=args.verify_cert)
    if meta_r.status_code == 404:
        print("Unknown file_id.")
        sys.exit(1)
    meta_r.raise_for_status()
    meta = meta_r.json()

    passphrase = get_passphrase()
    salt = bytes.fromhex(meta["salt"])
    aes_key, mac_key = derive_keys(passphrase, salt)

    out_path = args.out or meta["filename"]
    with open(out_path, "wb") as out_f:
        for index in range(meta["total_chunks"]):
            r = requests.get(f"{args.server}/files/{args.file_id}/chunks/{index}", verify=args.verify_cert)
            r.raise_for_status()
            body = r.json()
            iv = base64.b64decode(body["iv"])
            ciphertext = base64.b64decode(body["ciphertext"])
            tag = base64.b64decode(body["tag"])

            try:
                plaintext = verify_and_decrypt_chunk(aes_key, mac_key, iv, ciphertext, tag)
            except ValueError as e:
                print(f"Chunk {index}: {e}")
                print("Aborting - wrong passphrase, or the data was corrupted/tampered with.")
                out_f.close()
                os.remove(out_path)
                sys.exit(1)

            out_f.write(plaintext)
            print(f"  verified + decrypted chunk {index + 1}/{meta['total_chunks']}")

    print(f"\nSaved to {out_path}")


def list_files(args):
    r = requests.get(f"{args.server}/files", verify=args.verify_cert)
    r.raise_for_status()
    files = r.json()
    if not files:
        print("No files on server.")
        return
    for f in files:
        print(f"{f['file_id']}  {f['filename']}  ({f['received_chunks']}/{f['total_chunks']} chunks)")


def main():
    parser = argparse.ArgumentParser(description="Secure file transfer client")
    parser.add_argument("--server", default="https://localhost:5000")
    parser.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE)
    parser.add_argument(
        "--verify-cert",
        default=False,
        action="store_true",
        help="Verify the server's TLS cert against a CA bundle (off by default - "
             "local self-signed certs won't validate otherwise)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    up = sub.add_parser("upload", help="Encrypt and upload a file")
    up.add_argument("file")
    up.set_defaults(func=upload)

    res = sub.add_parser("resume", help="Resume an interrupted upload")
    res.add_argument("file")
    res.add_argument("file_id")
    res.set_defaults(func=resume_upload)

    down = sub.add_parser("download", help="Download and decrypt a file")
    down.add_argument("file_id")
    down.add_argument("--out", default=None)
    down.set_defaults(func=download)

    ls = sub.add_parser("list", help="List files on the server")
    ls.set_defaults(func=list_files)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
