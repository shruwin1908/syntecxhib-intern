package com.example.encryptedchat

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(
    private val messages: MutableList<Message>,
    private val cryptoManager: CryptoManager,
    private val onDecryptError: (Message) -> Unit
) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    companion object {
        private const val VIEW_TYPE_SENT = 1
        private const val VIEW_TYPE_RECEIVED = 2
    }

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textBody: TextView = itemView.findViewById(R.id.textMessageBody)
        val textTime: TextView = itemView.findViewById(R.id.textMessageTime)
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isSender) VIEW_TYPE_SENT else VIEW_TYPE_RECEIVED
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val layoutRes = if (viewType == VIEW_TYPE_SENT)
            R.layout.item_message_sent else R.layout.item_message_received
        val view = LayoutInflater.from(parent.context).inflate(layoutRes, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]

        // Decrypt only at display-time; storage always stays ciphertext.
        val plainText: String = try {
            cryptoManager.decrypt(CryptoManager.EncryptedPayload(message.cipherText, message.iv))
        } catch (e: Exception) {
            onDecryptError(message)
            "[Unable to decrypt message]"
        }

        holder.textBody.text = plainText
        holder.textTime.text = DateFormat.format("hh:mm a", message.timestamp)
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(message: Message) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
}
