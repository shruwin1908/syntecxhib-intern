# Encrypted File Transfer & Secure File Storage

Project 2: client/server system that encrypts files client-side (AES-256 +
HMAC-SHA256), chunks large files with resume support, transfers them over
HTTPS, and stores them encrypted at rest on the server.

## How it satisfies the brief

| Requirement | Where |
|---|---|
| Encrypted upload/download (AES + secure channel) | `crypto_utils.py` (AES-256-CBC) + HTTPS in `server.py`/`client.py` |
| Chunking, integrity checks (HMAC), resume | `chunker.py` + per-chunk HMAC-SHA256 in `crypto_utils.py` + `client.py resume` command |
| Files stored encrypted on disk, safe retrieval | `server.py` writes raw `iv+tag+ciphertext` to disk; decryption only ever happens client-side |
| Threat model discussion | See below |

## Setup

```bash
git clone <this-repo>
cd secure-file-transfer
python3 -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python generate_cert.py       # creates cert.pem / key.pem for local HTTPS
```

## Running it

**Terminal 1 - start the server:**
```bash
python server.py
```
This serves on `https://localhost:5000` using the cert you just generated.

**Terminal 2 - upload a file:**
```bash
python client.py upload path/to/myfile.pdf
```
You'll be prompted for a passphrase (twice, to confirm). This passphrase
never leaves your machine — it's used locally to derive the AES and HMAC
keys via PBKDF2. The command prints a `file_id`; save it.

**Download it back:**
```bash
python client.py download <file_id> --out restored.pdf
```
You'll be prompted for the same passphrase. Each chunk's HMAC is verified
*before* decryption — if the passphrase is wrong or the data was tampered
with, it aborts and deletes the partial output instead of writing garbage.

**List files on the server:**
```bash
python client.py list
```

**Resume an interrupted upload** (e.g. connection dropped partway through):
```bash
python client.py resume path/to/myfile.pdf <file_id>
```
It checks `/files/<id>/status` for which chunk indices the server already
has and only (re-)encrypts and sends the missing ones.

## Threat model & mitigations

**Man-in-the-middle (network attacker).**
Two independent layers protect against this:
1. **Transport layer** — all client↔server traffic runs over HTTPS/TLS
   (`server.py` loads `cert.pem`/`key.pem`), so a passive eavesdropper on
   the network can't read chunk contents in transit.
2. **Application layer** — even if TLS were somehow stripped or a malicious
   proxy sat in the middle, each chunk is independently encrypted
   (AES-256-CBC) and authenticated (HMAC-SHA256, encrypt-then-MAC). The
   client verifies the HMAC *before* decrypting, so any bit-flip or
   substitution attack on a chunk is detected and the download aborts
   rather than silently returning corrupted or attacker-controlled data.

   Caveat: this demo's self-signed cert is not pinned or validated by
   default (`--verify-cert` is off), so a MITM *could* present a different
   cert and the client wouldn't notice at the TLS layer alone — it would
   only be caught by the HMAC check above. In production you'd use a
   CA-issued cert and enable certificate verification (or pin the cert).

**Server compromise.**
The server only ever stores/serves ciphertext + HMAC tags — it never
receives the passphrase or the derived AES/HMAC keys. An attacker who
fully compromises the server (reads the disk, dumps the database) gets
encrypted blobs they cannot decrypt without the user's passphrase. This is
a "blind storage" / zero-knowledge-server design.

**Key management (the weakest link here).**
This demo derives keys from a user-supplied passphrase via PBKDF2 (200,000
iterations, SHA-256) with a random 16-byte salt stored alongside the file
metadata. Trade-offs to be upfront about:
- The passphrase has to be communicated to whoever downloads the file
  through some *other* channel (in person, a password manager, a secure
  messenger) — this system doesn't solve key distribution, only encryption.
- A weak/reused passphrase undermines everything regardless of how strong
  the AES/HMAC is — `client.py` warns on short passphrases but can't
  enforce strength.
- Production systems typically replace the shared-passphrase model with
  asymmetric key exchange (e.g. ECDH per session, or recipient public-key
  encryption so no secret ever needs to be manually shared) and/or a
  proper KMS with key rotation and per-user access control.

**Replay / tampering with chunk order.**
Chunks are addressed by index and bound to a specific `file_id`, so a
server (malicious or buggy) returning stale or reordered chunks under the
wrong index would still pass its own HMAC check (the tag only covers that
chunk's own bytes) but produce a corrupted file on reassembly — not a
confidentiality break, but worth noting. A hardened version would include
the chunk index and file_id in the HMAC'd data (not just `iv+ciphertext`)
to bind each chunk to its position.

**Denial of service.**
`server.py` caps total stored size per file (`MAX_FILE_SIZE_BYTES`) as a
basic guard; a real deployment would add rate limiting and auth before
exposing this beyond localhost.

## Project layout

```
secure-file-transfer/
├── server.py          # Flask HTTPS server - blind encrypted storage
├── client.py          # CLI: upload / resume / download / list
├── crypto_utils.py     # PBKDF2 key derivation, AES-256-CBC + HMAC-SHA256
├── chunker.py          # file chunking for large-file + resume support
├── generate_cert.py    # one-time self-signed TLS cert generator
├── requirements.txt
└── storage/             # server's on-disk encrypted chunk storage (gitignored)
```

## Known limitations / ideas to extend

- Add the chunk index + file_id into the HMAC'd bytes (see "replay" above).
- Swap the shared passphrase for per-recipient public-key encryption.
- Add basic auth / API keys on the server so it's not wide open to anyone
  who can reach it on the network.
- Switch to AES-GCM (AEAD) to combine the encrypt+MAC step into one
  primitive instead of doing it manually.
