package com.example.encryptedchat

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * MessageRepository
 *
 * Persists message HISTORY locally as ciphertext + IV only (never plaintext).
 * This demonstrates "secure storage" in the sense that even if the storage
 * file is copied off the device, the messages remain unreadable without the
 * AES key sealed inside the Android Keystore.
 *
 * Note on production hardening (documented, not implemented, for prototype
 * scope): a real app should also use EncryptedSharedPreferences /
 * SQLCipher for the metadata file itself, since here only the message
 * *content* is encrypted -- timestamps and message count are stored in
 * cleartext JSON, which is an acceptable simplification for this prototype
 * but a metadata leak in a production system.
 */
class MessageRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("encrypted_chat_store", Context.MODE_PRIVATE)

    private val keyMessages = "messages_json"

    fun loadMessages(): MutableList<Message> {
        val json = prefs.getString(keyMessages, null) ?: return mutableListOf()
        val result = mutableListOf<Message>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    Message(
                        id = obj.getLong("id"),
                        cipherText = obj.getString("cipherText"),
                        iv = obj.getString("iv"),
                        isSender = obj.getBoolean("isSender"),
                        timestamp = obj.getLong("timestamp")
                    )
                )
            }
        } catch (e: Exception) {
            // Corrupt or unreadable history should never crash the app.
            return mutableListOf()
        }
        return result
    }

    fun saveMessages(messages: List<Message>) {
        val arr = JSONArray()
        for (m in messages) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("cipherText", m.cipherText)
            obj.put("iv", m.iv)
            obj.put("isSender", m.isSender)
            obj.put("timestamp", m.timestamp)
            arr.put(obj)
        }
        prefs.edit().putString(keyMessages, arr.toString()).apply()
    }
}
