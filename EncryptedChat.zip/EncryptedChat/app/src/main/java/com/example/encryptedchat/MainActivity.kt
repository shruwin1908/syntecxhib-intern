package com.example.encryptedchat

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.encryptedchat.databinding.ActivityMainBinding

/**
 * MainActivity
 *
 * A minimal encrypted chat prototype:
 *  - Typed messages are AES-GCM encrypted client-side before being stored.
 *  - "Receiving" is simulated with an automatic echo reply after a short
 *    delay, decrypted and encrypted the same way a real remote message
 *    would be, to demonstrate the full round trip without needing a backend.
 *  - Full message history persists (as ciphertext) across app restarts.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cryptoManager: CryptoManager
    private lateinit var repository: MessageRepository
    private lateinit var adapter: MessageAdapter
    private val messages = mutableListOf<Message>()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cryptoManager = CryptoManager()
        repository = MessageRepository(this)

        // Load any previously stored (encrypted) history.
        messages.addAll(repository.loadMessages())

        adapter = MessageAdapter(messages, cryptoManager) { badMessage ->
            Toast.makeText(
                this,
                "Warning: could not decrypt message ${badMessage.id}. It may be corrupted.",
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.recyclerMessages.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        binding.recyclerMessages.adapter = adapter
        if (messages.isNotEmpty()) {
            binding.recyclerMessages.scrollToPosition(messages.size - 1)
        }

        binding.buttonSend.setOnClickListener { handleSend() }
    }

    private fun handleSend() {
        val text = binding.editMessageInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            Toast.makeText(this, "Type a message first", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val encrypted = cryptoManager.encrypt(text)
            val message = Message(
                id = System.currentTimeMillis(),
                cipherText = encrypted.cipherText,
                iv = encrypted.iv,
                isSender = true,
                timestamp = System.currentTimeMillis()
            )
            adapter.addMessage(message)
            persistAndScroll()
            binding.editMessageInput.text?.clear()

            // Simulate the other party receiving and echoing the message back,
            // to demonstrate a full send -> receive -> decrypt round trip.
            simulateIncomingEcho(text)

        } catch (e: Exception) {
            // Never crash on a crypto failure -- surface it to the user instead.
            Toast.makeText(
                this,
                "Encryption failed: ${e.localizedMessage ?: "unknown error"}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun simulateIncomingEcho(originalText: String) {
        mainHandler.postDelayed({
            try {
                val replyText = "Echo: $originalText"
                val encrypted = cryptoManager.encrypt(replyText)
                val message = Message(
                    id = System.currentTimeMillis(),
                    cipherText = encrypted.cipherText,
                    iv = encrypted.iv,
                    isSender = false,
                    timestamp = System.currentTimeMillis()
                )
                adapter.addMessage(message)
                persistAndScroll()
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Failed to process incoming message: ${e.localizedMessage}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }, 800L)
    }

    private fun persistAndScroll() {
        repository.saveMessages(messages)
        binding.recyclerMessages.scrollToPosition(messages.size - 1)
    }
}
