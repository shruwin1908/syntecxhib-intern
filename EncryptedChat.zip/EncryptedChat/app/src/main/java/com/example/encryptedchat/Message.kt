package com.example.encryptedchat

/**
 * Represents one stored chat message. Only ciphertext + IV are persisted;
 * the plaintext is decrypted on the fly only when displayed.
 */
data class Message(
    val id: Long,
    val cipherText: String,
    val iv: String,
    val isSender: Boolean,
    val timestamp: Long
)
