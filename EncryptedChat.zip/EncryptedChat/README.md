# Encrypted Android Chat (Prototype)

This is a working Android Studio project that satisfies the "Project 2" brief:

- Encrypts messages on the client using **AES-256/GCM** before sending/storing.
- Implements sending and receiving (an automatic echo simulates the other
  side of the conversation, so you can see full send -> receive -> decrypt
  flow without needing a real backend).
- Encryption/decryption happens locally on the device.
- Message keys are generated and stored in the **Android Keystore** — the
  raw key material never leaves secure hardware and is never stored in
  plaintext anywhere in the app.
- Message history persists across app restarts (stored as ciphertext + IV
  only — never plaintext).
- Basic chat UI with bubbles, timestamps, and error handling (empty input,
  failed encryption, corrupted/undecryptable messages).

## How to open and run it

1. Open **Android Studio** (Hedgehog / 2023.1+ recommended).
2. Choose **File -> Open**, then select the unzipped `EncryptedChat` folder
   (the one containing `settings.gradle`).
3. Let Gradle sync (first sync will download dependencies — needs internet).
4. Plug in a device or start an emulator running **API 23+**.
5. Click **Run ▶** (or Shift+F10).
6. Type a message and hit Send — you'll see your message appear encrypted-
   then-decrypted instantly, followed by a simulated "Echo:" reply a moment
   later, proving the round trip works.

## Project structure

```
EncryptedChat/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/encryptedchat/
│       │   ├── MainActivity.kt        (chat screen, send/receive logic)
│       │   ├── CryptoManager.kt       (AES-GCM + Android Keystore)
│       │   ├── Message.kt             (data model)
│       │   ├── MessageAdapter.kt      (RecyclerView adapter, decrypts to display)
│       │   └── MessageRepository.kt   (persists ciphertext to SharedPreferences)
│       └── res/
│           ├── layout/                (activity_main, message bubbles)
│           ├── drawable/              (bubble + input backgrounds)
│           └── values/                (strings, theme)
├── build.gradle
└── settings.gradle
```

## Key security notes (for your write-up / demo)

- **Where the key lives:** generated once via `KeyGenerator` targeting
  `AndroidKeyStore`; Android keeps it in a secure area (hardware-backed on
  most modern devices) and the app only ever references it by alias.
- **What's stored on disk:** only Base64 ciphertext + IV, in
  `SharedPreferences`. Nothing plaintext ever touches storage.
- **Known risk / limitation (documented, appropriate for a prototype):**
  uninstalling the app deletes the Keystore key, permanently orphaning any
  saved history — there's no key backup/escrow. Also, message *metadata*
  (timestamp, sender flag) is not itself encrypted, only the message body.
- **GCM mode** was chosen over CBC because it also authenticates the
  ciphertext, so any tampering is detected and decryption fails safely
  instead of silently returning garbage.

## Extending it further

- Swap the simulated echo for a real transport (Bluetooth, Wi-Fi Direct, or
  a server) — the crypto layer is already transport-agnostic.
- Add per-contact key pairs (e.g. ECDH) if you want end-to-end encryption
  between two distinct devices rather than local-only encryption.
- Swap `SharedPreferences` for `EncryptedSharedPreferences` or a
  SQLCipher-backed Room database to also protect metadata.
